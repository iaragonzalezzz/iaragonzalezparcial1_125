package iaragonzalezparcial1_125;

import java.util.ArrayList;
import java.util.List;

public class Jardin {

    private List <Planta> plantas;

    public Jardin() {
        plantas = new ArrayList<>();
    }
    
    public void agregarPlanta(Planta planta){
        if (plantas.contains(planta)) {
            throw new PlantaRepetidaException();
        }
        plantas.add(planta);
    }
    
    public void mostrarPlantas(){
        for (Planta planta : plantas) {
            System.out.println(planta);
        }
    }
    
    public void podarPlantas(){
        for (Planta planta : plantas) {
            if (planta instanceof Arbusto ar) {
                ar.podar();
            }
            else if (planta instanceof Arbol a) {
                a.podar();
            }
            else{
                System.out.println("No puede podarse, es una flor.");
            }
            
        }
    }
    
}
