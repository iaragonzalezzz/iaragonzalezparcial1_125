package iaragonzalezparcial1_125;
public class iaragonzalezparcial1_125 {
    public static void main(String[] args) {
        
        Jardin jardin = new Jardin();
        Arbol arbol = new Arbol(24.10, "Roble", "Zona norte", "Seco");
        Arbol arbol2 = new Arbol(19, "Jacaranda", "Zona sur", "Soleado");
        Arbusto arbusto = new Arbusto(7, "Roble", "Zona norte", "Arido");
        Arbusto arbusto2 = new Arbusto(10, "Arbusto", "Zona sur", "Humedo");
        Flores flor = new Flores(Clima.PRIMAVERA, "Alegria doble", "Zona este", "Sombra");
        
        try {
            jardin.agregarPlanta(arbol);
            jardin.agregarPlanta(arbol2);
            jardin.agregarPlanta(arbusto2);
            jardin.agregarPlanta(flor);
            jardin.agregarPlanta(arbusto);
            
        }
        catch (PlantaRepetidaException e) {
            System.out.println(e.getMessage());
        }
        catch (Exception e) {
            System.out.println(e);
        }
        
        jardin.mostrarPlantas();
        jardin.podarPlantas();
        
        
    }
    
}
