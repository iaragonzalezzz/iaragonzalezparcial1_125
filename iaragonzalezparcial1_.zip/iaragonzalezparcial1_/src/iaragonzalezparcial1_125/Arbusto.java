package iaragonzalezparcial1_125;

public class Arbusto extends Planta implements Podable {
    private static final int MAX_DENSIDAD = 10;
    private static final int MIN_DENSIDAD = 1;
    private int densidadFollaje;

    public Arbusto(int densidadFollaje, String nombre, String ubicacion, String clima) {
        super(nombre, ubicacion, clima);
        this.densidadFollaje = valoresDensidadPermitidos(densidadFollaje);
    }

    @Override
    public void podar() {
        System.out.println("El arbusto se ha podado.");
    }

    private int valoresDensidadPermitidos(int densidad) {
        if (densidad >= MIN_DENSIDAD && densidad <= MAX_DENSIDAD) {
            return densidad;
        } else {
            throw new IllegalArgumentException("La densidad debe estar entre " + MIN_DENSIDAD + " y " + MAX_DENSIDAD);
        }
    }

    @Override
    public String toString() {
        return super.toString() + " Densidad del follaje: " + densidadFollaje;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        Arbusto other = (Arbusto) obj;
        return super.equals(other) && this.densidadFollaje == other.densidadFollaje;
    }

    @Override
    public int hashCode() {
        int hash = 37;
        hash = 37 * hash + (super.hashCode());
        hash = 37 * hash + densidadFollaje;
        return hash;
    }
}
