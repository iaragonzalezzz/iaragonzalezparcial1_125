package iaragonzalezparcial1_125;
public class PlantaRepetidaException extends RuntimeException{
    private static final String MESSAGE = "La planta es repetida";
    
    public PlantaRepetidaException(){
        super(MESSAGE);
    }
    
}