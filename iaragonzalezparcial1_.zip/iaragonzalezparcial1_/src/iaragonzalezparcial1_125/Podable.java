package iaragonzalezparcial1_125;
public interface Podable {
    void podar();
}
